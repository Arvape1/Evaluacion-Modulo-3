exports.libro = require('./libro');
exports.persona = require('./persona');
exports.categoria = require('./categoria');
