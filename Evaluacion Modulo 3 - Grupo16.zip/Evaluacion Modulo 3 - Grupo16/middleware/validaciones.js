const params = (req, res, next) => {
  const { id } = req.params;
  try {
    if (!Number(id)) {
      throw new Error("ID inválida");
    }
    next();
  } catch (error) {
    next(error);
  }
};


const validarNombre = (req, res, next) => {
  const { nombre } = req.body;
  try {
    if (!nombre) throw new Error("Falta enviar datos");
    if (nombre.length < 3)
      throw new Error("El nombre debe contener al menos 3 caracteres.");
    next();
  } catch (error) {
    next(error);
  }
};

const validarRegistro = (req, res, next) => {
  let { nombre, apellido, alias, email } = req.body;
  try {
    if (!nombre || !apellido || !alias || !email)
      throw new Error("Falta enviar datos");
    if (nombre.length < 3)
      throw new Error("El nombre debe contener al menos 3 caracteres.");
    if (!/^[a-z]+$/i.test(nombre))
      throw new Error("El nombre debe contener solo caracteres de la a-z");
    if (apellido.length < 3)
      throw new Error("El apellido debe contener al menos 3 carácteres.");
    if (!/^[a-z]+$/i.test(apellido))
      throw new Error("El apellido debe contener solo caracteres de la a-z");
    if (alias.length < 3)
      throw new Error("El alias debe contener al menos 5 caracteres.");
    if (!/^[a-z0-9_.]+$/i.test(alias))
      throw new Error("El alias debe contener solo caracteres de la a-z");
    if (!/^[a-z0-9_.]+@[a-z0-9]+\.[a-z0-9_.]+$/i.test(email))
      throw new Error("El email debe ser válido");
    next();
  } catch (err) {
    next(err);
  }
};

const bodyLibro = (req, res, next) => {
  try {
    if (!req.body.nombre || !req.body.categoria_id)
      throw new Error("Campos nombre y categoria obligatorios.");

    let { nombre, descripcion } = req.body;

    nombre = nombre.replace(/  +/gi, " ");
    nombre = nombre.trim();

    if (!/^[A-Z]{2,}\s?(([A-Z]{1,}\s?){1,15})/gi.test(nombre))
      throw new Error(
        "El nombre debe contener solo caracteres alfabéticos, mínimo 3."
      );

    descripcion = descripcion.trim();
    req.body.descripcion = descripcion.replace(/  +/gi, " ");

    if (descripcion.length > 200)
      throw new Error("La descripción no debe tener mas de 200 caracteres");

    next();
  } catch (err) {
    next(err);
  }
};

const personaok = (req, res, next) => {
  try {
    if (!req.body.persona_id)
      throw new Error(
        "El campo ID de la persona a prestar el libro es obligatorio"
      );
    next();
  } catch (err) {
    next(err);
  }
};

module.exports = {
  params,
  validarRegistro,
  bodyLibro,
  personaok,
  validarNombre,
};
