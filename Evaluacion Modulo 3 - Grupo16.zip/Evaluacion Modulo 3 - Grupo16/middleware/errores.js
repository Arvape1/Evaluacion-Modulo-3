exports.is500 = (error, req, res, next) => {
  if(error.code === undefined){
      error.status = 413;
    }
  res.status(error.status || 500);
  res.statusCode === 404 || res.statusCode === 413 
    ? res.json({
        mensaje: error.message,
      })
    : res.json({
        mensaje: "Error inesperado"+ error.message,
      })
};

exports.is404 = (req, res, next) => {
  const error = new Error("La pagina que busca no existe.");
  error.status = 404;
  next(error);
};
