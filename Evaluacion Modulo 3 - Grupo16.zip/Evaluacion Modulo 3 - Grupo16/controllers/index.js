exports.librosCtrl  = require('./libroController');
exports.personasCtrl  = require('./personaController');
exports.categoriasCtrl  = require('./categoriaController');