const {  libro, persona, categoria  } = require("../models");

const lista = async(req, res, next)=>{
    try {   
        let respuesta = await categoria.lista();
        if(respuesta.length === 0)throw new Error('No se encontraron categorias para mostrar');
        res.status(200).json(respuesta);
    } catch (err) {
        next(err);
    }
}

const buscar = async(req, res, next)=> {
    try {
        const { id } = req.params;
        let respuesta = await  categoria.buscar(id);
        if(respuesta.length === 0)throw new Error('No se pudo encontrar categoria');
        res.status(200).json(respuesta);
    }
    catch (err) {
        if(err.code === undefined){
            res.status(413).json({
                error: err.message
            })
        }else{
            next(err);
        }
}
}

const agregar = async (req, res, next)=> {
    try{
        const nombre = req.body.nombre.toUpperCase();
        let respuesta = await categoria.buscarNombre(nombre);
        if (respuesta.length > 0)throw new Error ('Nombre de categoria duplicado');

        respuesta = await categoria.agregar(nombre);

        respuesta = await categoria.buscar(respuesta.insertId);

        res.status(200).json(respuesta);
    }
    catch (err) {
        next(err);
    }
}

const eliminar = async(req, res, next)=>{
    try {
        const { id } = req.params;
        let respuesta = await categoria.buscar(id);
        if(respuesta.length === 0)throw new Error('Categoria inexistente');

        
        respuesta = await categoria.buscarCategoriaLibro(id);
        if(respuesta.length > 0)throw new Error('No se puede eliminar categoria ya que contiene libros asociados a la misma') 

        respuesta = await categoria.eliminar(id);

        res.status(200).json({
            mensaje: 'Se ha borrado correctamente la categoria'
        });

    } catch (err) {
        next(err);
    }
}

module.exports = {
    lista,
    eliminar,
    buscar,
    agregar
};
